<?php

define('GRAPHQL_DEBUG', true);
